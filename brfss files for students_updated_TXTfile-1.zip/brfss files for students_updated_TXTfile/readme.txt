BRFSS for Big Data Analytics Assessment 20/21

The supplied CSV file is a cleaned-up version of that provided by https://healthdata.gov/State/Behavioral-Risk-Factor-Surveillance-Survey-2015/r4vf-8w6z. We have made some changes to the way data is represented, and removed some rows that had problems, so that it will load as-is into WEKA. Other than that, it's the same dataset. 